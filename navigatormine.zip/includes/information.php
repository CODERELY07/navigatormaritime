
<div class="row">
    <div class="col-lg-6 text-secondary">
    <i class="fa-solid fa-location-dot dark-color"></i>
        <h4 class="dark-color d-inline text-capitalize bolder mt">Address</h4>
        <p class="mt">Unit 701 S&L Building 1500 Roxas Boulevard, 1000 Ermita, Manila</p>
    </div>
    <div class="col-lg-6 text-secondary">
        <i class="fa-solid fa-phone dark-color"></i>
        <h4 class="dark-color text-capitalize bolder d-inline pt-3">Contact INFO</h4>
        <p class="mt">
        +632 527 1069 LOCAL <br>
        +632 516 2993 LOCAL <br>
        +632 516 3674 <br>
        SUN: 09493326357 / 09985944089 <br>
        GLOBE: 09957894170 / 09778337279 <br>
        <br>
        <br>
        info@navigatormaritime.com
        </p>
    </div>
</div>

